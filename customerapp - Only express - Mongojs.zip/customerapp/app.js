const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const expressValidator = require('express-validator');
const mongojs = require('mongojs');
const ObjectId = mongojs.ObjectId;
const db = mongojs('customerapp', ['users']);

const app = express();
const port = 3000;

var users = [
    {
        "first_name": "Manoj",
        "last_name": "Kumar",
        "age": "25"
    },
    {
        "first_name": "Mahesh",
        "last_name": "Kumar",
        "age": "23"
    },
    {
        "first_name": "Kranthi",
        "last_name": "Kumar",
        "age": "18"
    }
];

app.set("view engine", "ejs");
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


app.use(function (req, res, next) {
    res.locals.errors = null;
    next();
});

app.use(expressValidator({
    errorFormatter: function (param, msg, value) {
        var namespace = param.split('.')
            , root = namespace.shift()
            , formParam = root;

        while (namespace.length) {
            formParam += '[' + namespace.shift() + ']';
        }
        return {
            param: formParam,
            msg: msg,
            value: value
        };
    }
}));

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    db.users.find(function (err, docs) {
        // console.log(docs);
        res.render('index', {
            title: "Customers",
            users: docs
        });
    });

    // res.send('Here you are');
    // res.json(users);
});


app.post('/users/add', (req, res) => {
    // console.log("Form submitted");
    req.checkBody('first_name', 'First name is required.').notEmpty();
    req.checkBody('last_name', 'Last name is required.').notEmpty();
    req.checkBody('email', 'Email is required.').notEmpty();

    let errors = req.validationErrors();

    if (errors) {
        // console.log("Errors");

        res.render('index', {
            title: "Customers",
            users: users,
            errors: errors
        });
    } else {

        var newUser = {
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            email: req.body.email
        }

        // console.log("Okay");
        db.users.insert(newUser, function (err, result) {
            if (err) {
                console.log("Insertion failed..." + err);
            } else {
                res.redirect('/');
            }
        });

    }
});


app.delete('/users/delete/:id', (req, res) => {
    db.users.remove({ _id: ObjectId(req.params.id) }, function (err, result) {
        if (err) {
            console.log('deleted!');
        }
        res.redirect('/');
    });
});

app.listen(port, () => {
    console.log('Server started at port: ' + port);
});

// console.log("Hello world...!");