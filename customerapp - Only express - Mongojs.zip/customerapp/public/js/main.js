$(document).ready(function () {
    $(".deleteUser").on("click", deleteUser);
});

function deleteUser() {
    var confirmation = confirm("Are you sure, you want to delete this user?");
    if (confirmation) {
        $thisId = $(this).data("id");
        alert($thisId);
        $.ajax({
            type: "DELETE",
            url: '/users/delete/' + $thisId
        }).done(function (response) {
            window.location.replace('/');
        });

    } else {
        return false;
    }

    return false;
}
